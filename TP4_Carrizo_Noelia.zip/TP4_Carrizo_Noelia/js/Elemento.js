class Elemento {

    constructor() {}

    status() {
        return;
    }

    /** uso uno generico para poder ver contra que elemento choca si es enemigo o suma de puntos o bonus */
    impacto() {

    }
}