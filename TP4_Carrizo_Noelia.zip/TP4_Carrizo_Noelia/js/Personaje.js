class Personaje {

    constructor() {

    }

    status() {
        return ;
    }

}